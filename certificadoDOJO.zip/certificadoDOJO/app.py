from flask import Flask, render_template, request, redirect, url_for, flash, session
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'tu_clave_secreta'  # Cambia esto a una clave secreta real

# Conectar a la base de datos
def get_db_connection():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row  # Para poder acceder a las columnas como un diccionario
    return conn

# Inicializar la base de datos
def init_db():
    conn = get_db_connection()
    conn.execute('''CREATE TABLE IF NOT EXISTS users (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        nombre TEXT UNIQUE,
                        apellido TEXT UNIQUE,
                        email TEXT UNIQUE,
                        password TEXT
                    )''')
    conn.execute('''CREATE TABLE IF NOT EXISTS missions (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        name TEXT,
                        leader TEXT,
                        date datetime,
                        volunteers_needed INTEGER,
                        description TEXT,
                        user_id INTEGER,
                        FOREIGN KEY (user_id) REFERENCES users(id)
                    )''')
    conn.commit()
    conn.close()

# Ruta para la página principal
@app.route('/')
def index():
    if 'username' not in session:
        return redirect(url_for('login'))  # Redirigir al login si no está autenticado

    username = session['username']
    conn = get_db_connection()
    missions = conn.execute('SELECT * FROM missions WHERE user_id = (SELECT id FROM users WHERE username = ?) LIMIT 5', (username,)).fetchall()
    conn.close()

    return render_template('login.html', username=username, missions=missions)

# Ruta para crear nueva misión
@app.route('/nueva.html', methods=['GET', 'POST'])
def new_mission():
    if 'username' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        name = request.form['name']
        date = request.form['date']
        voluntarios_requeridos = request.form['voluntarios_requeridos']
        description = request.form['description']

        if not description:
            flash('La descripción no puede quedar vacía.', 'error')
            return redirect(url_for('nueva.html'))

        if int(voluntarios_requeridos) < 2 or int(voluntarios_requeridos) > 20:
            flash('El número de voluntarios debe ser entre 2 y 20.', 'error')
            return redirect(url_for('new_mission'))

        user_id = session['user_id']
        conn = get_db_connection()
        conn.execute('INSERT INTO missions (name, leader, date, volunteers_needed, description, user_id) VALUES (?, ?, ?, ?, ?, ?)', 
                     (name, session['username'], date, voluntarios_requeridos, description, user_id))
        conn.commit()
        conn.close()
        flash('Misión creada exitosamente', 'success')
        return redirect(url_for('dashboard.html'))

    return render_template('dashboard.html')

# Ruta para login
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        nombre = request.form['nombre']
        apellido = request.form['apellido']
        email = request.form['email']
        password = request.form['password']
        conn = get_db_connection()
        user = conn.execute('SELECT * FROM users WHERE email = ?, ?, ?', (nombre, apellido, email,)).fetchone()
        conn.close()

        if user and check_password_hash(user['password'], password):
            session['username'] = user['username']
            session['user_id'] = user['id']
            flash('Inicio de sesión exitoso', 'success')
            return redirect(url_for('index'))
        else:
            flash('Credenciales incorrectas', 'error')
    return render_template('login.html')

# Ruta para cerrar sesión
@app.route('/logout')
def logout():
    session.pop('username', None)
    session.pop('user_id', None)
    flash('Sesión cerrada', 'success')
    return redirect(url_for('login'))

# Ruta para editar misión
@app.route('/edit_mission/<int:mission_id>', methods=['GET', 'POST'])
def edit_mission(mission_id):
    if 'username' not in session:
        return redirect(url_for('login'))

    conn = get_db_connection()
    mission = conn.execute('SELECT * FROM missions WHERE id = ?', (mission_id,)).fetchone()
    conn.close()

    if request.method == 'POST':
        name = request.form['name']
        date = request.form['date']
        volunteers_needed = request.form['volunteers_needed']
        description = request.form['description']

        if not description:
            flash('La descripción no puede quedar vacía.', 'error')
            return redirect(url_for('edit_mission', mission_id=mission_id))

        conn = get_db_connection()
        conn.execute('UPDATE missions SET name = ?, date = ?, volunteers_needed = ?, description = ? WHERE id = ?',
                     (name, date, volunteers_needed, description, mission_id))
        conn.commit()
        conn.close()
        flash('Misión actualizada exitosamente', 'success')
        return redirect(url_for('index'))

    return render_template('edit_mission.html', mission=mission)

# Ruta para eliminar misión
@app.route('/delete_mission/<int:mission_id>')
def delete_mission(mission_id):
    if 'username' not in session:
        return redirect(url_for('login'))

    conn = get_db_connection()
    conn.execute('DELETE FROM missions WHERE id = ?', (mission_id,))
    conn.commit()
    conn.close()
    flash('Misión eliminada', 'success')
    return redirect(url_for('index'))

# Registro de usuario con contraseña hash
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        hashed_password = generate_password_hash(password)

        conn = get_db_connection()
        conn.execute('INSERT INTO users (username, email, password) VALUES (?, ?, ?)', 
                     (username, email, hashed_password))
        conn.commit()
        conn.close()
        flash('Usuario registrado exitosamente', 'success')
        return redirect(url_for('login'))

    return render_template('register.html')

# Iniciar la aplicación
if __name__ == '__main__':
    init_db()
    app.run(debug=True)
